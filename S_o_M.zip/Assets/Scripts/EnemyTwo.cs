﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTwo : Enemy
{
    protected override void Die()
    {
        base.Die();
    }

}

using UnityEngine;
using System.Collections;

public class qd_Constant
{
	public const string ParentToHitTransform = "qd_ParentToHitTransform";
}
